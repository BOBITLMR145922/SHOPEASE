import pandas as pd
from faker import Faker
import random
import datetime

fake = Faker()

def generate_data(num_records):
    data = []
    used_emails = set()
    for _ in range(num_records):
        email = fake.email()
        while email in used_emails:
            email = fake.email()
        used_emails.add(email)
        customer_name = fake.name()
        product = fake.word()
        sale_amount = round(random.uniform(10, 1000), 2)
        order_date = fake.date_time_between(start_date='-1y', end_date='now').strftime('%Y-%m-%d %H:%M:%S')
        order_items = random.randint(1, 10)
        data.append([email, customer_name, product, sale_amount, order_date, order_items])
    return data

num_records = 11000
data = generate_data(num_records)

# Define column names
columns = ['Email', 'Customer Name', 'Product', 'Sale Amount', 'Order Date', 'Order Items']

# Create DataFrame
df = pd.DataFrame(data, columns=columns)

# Save to Excel
df.to_excel('generated_data.xlsx', index=False)

print(f"Generated {num_records} records and saved to 'generated_data.xlsx'")
