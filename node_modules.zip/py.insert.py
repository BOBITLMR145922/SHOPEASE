import pandas as pd
import psycopg2
from psycopg2 import Error

# Function to establish PostgreSQL connection
def connect_to_postgresql():
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="5432",
            host="localhost",
            port="5432",
            database="shopease"
        )
        return connection
    except Error as e:
        print(f"Error connecting to PostgreSQL: {e}")
        return None

# Function to create tables if they do not exist
def create_tables(connection):
    if connection is not None:
        try:
            cursor = connection.cursor()
            
            # Create Customers table with Unique Constraint on email
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Customers (
                    customer_id SERIAL PRIMARY KEY,
                    email VARCHAR UNIQUE,
                    customer_name VARCHAR
                )
            """)
            
            # Create Products table without unique constraint on product_name
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Products (
                    product_id SERIAL PRIMARY KEY,
                    product_name VARCHAR,
                    CONSTRAINT products_pk PRIMARY KEY (product_id)
                )
            """)
            
            # Create Orders table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Orders (
                    order_id SERIAL PRIMARY KEY,
                    customer_id INTEGER REFERENCES Customers(customer_id),
                    order_date DATE,
                    sale_amount NUMERIC
                )
            """)
            
            # Create OrderItems table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS OrderItems (
                    order_item_id SERIAL PRIMARY KEY,
                    order_id INTEGER REFERENCES Orders(order_id),
                    product_id INTEGER REFERENCES Products(product_id),
                    quantity INTEGER
                )
            """)
            
            connection.commit()
            print("Tables created successfully in PostgreSQL.")
        except Error as e:
            connection.rollback()
            print(f"Error creating tables in PostgreSQL: {e}")
        finally:
            cursor.close()

# Function to insert data into PostgreSQL tables
def insert_data(connection, df):
    if connection is not None:
        try:
            cursor = connection.cursor()
            
            # Insert into Customers table
            for index, row in df.iterrows():
                cursor.execute("""
                    INSERT INTO Customers (email, customer_name)
                    VALUES (%s, %s)
                    ON CONFLICT (email) DO NOTHING
                    RETURNING customer_id
                """, (row['Email'], row['Customer Name']))
                
                # Fetch customer_id if insertion was successful
                customer_id = cursor.fetchone()[0] if cursor.rowcount > 0 else None
                
                # Insert into Products table
                cursor.execute("""
                    INSERT INTO Products (product_name)
                    VALUES (%s)
                    RETURNING product_id
                """, (row['Product'],))
                
                # Fetch product_id if insertion was successful
                product_id = cursor.fetchone()[0] if cursor.rowcount > 0 else None
                
                # Insert into Orders table
                if customer_id is not None:
                    cursor.execute("""
                        INSERT INTO Orders (customer_id, order_date, sale_amount)
                        VALUES (%s, %s, %s)
                        RETURNING order_id
                    """, (customer_id, row['Order Date'], row['Sale Amount']))
                    
                    # Fetch order_id if insertion was successful
                    order_id = cursor.fetchone()[0] if cursor.rowcount > 0 else None
                    
                    # Insert into OrderItems table
                    if order_id is not None and product_id is not None:
                        cursor.execute("""
                            INSERT INTO OrderItems (order_id, product_id, quantity)
                            VALUES (%s, %s, %s)
                        """, (order_id, product_id, row['Order Items']))
                
            connection.commit()
            print("Data inserted successfully into PostgreSQL tables.")
        except Error as e:
            connection.rollback()
            print(f"Error inserting data into PostgreSQL: {e}")
        finally:
            cursor.close()

if __name__ == "__main__":
    # Replace with your Excel file path
    excel_file = 'generated_data.xlsx'

    # Connect to PostgreSQL
    connection = connect_to_postgresql()

    # Create tables if they do not exist
    if connection:
        create_tables(connection)

        # Extract data from Excel into a pandas DataFrame
        df = pd.read_excel(excel_file)

        # Insert data into PostgreSQL tables
        if not df.empty:
            insert_data(connection, df)
    else:
        print("Connection to PostgreSQL failed.")
